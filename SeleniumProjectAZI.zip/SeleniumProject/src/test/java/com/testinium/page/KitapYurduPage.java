package com.testinium.page;

import com.testinium.methods.Methods;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Random;

public class KitapYurduPage {
    Methods methods;
    Random random;
    Logger logger = LogManager.getLogger(ProductPage.class);

    public KitapYurduPage() {
        methods = new Methods();
        random = new Random();
    }

    public void selectPointsCatalog() {

        methods.click(By.cssSelector("div[class='lvl1catalog']"));
        methods.click(By.cssSelector("img[title='Puan Kataloğundaki Türk Klasikleri']"));
        methods.waitBySeconds(1);
        methods.selectByText(By.cssSelector("div[class='sort']>select[onchange='location = this.value;']"),"Yüksek Oylama");
        methods.waitBySeconds(5);
        methods.click(By.xpath("//span[text()='Tüm Kitaplar']"));
        methods.waitBySeconds(1);
        methods.click(By.xpath("//a[text()='Hobi']"));
        methods.waitBySeconds(1);
        selectRandomProduct();
        methods.waitBySeconds(1);
        methods.click(By.xpath("//span[text()='Sepete Ekle']"));
        methods.waitBySeconds(1);
        methods.click(By.xpath("//a[text()='Listelerim']"));
        methods.waitBySeconds(1);
        methods.click(By.cssSelector("a[href=\"https://www.kitapyurdu.com/index.php?route=account/favorite&selected_tags=0\"]"));
        methods.waitBySeconds(1);
        methods.click(By.xpath("//div[@class='product-list']/div[@class='product-cr'][3]"));
        methods.click(By.xpath("//div[@class='product-list']//div[@class='product-cr'][3]//i[@class='fa fa-heart-o']"));
        methods.waitBySeconds(3);
        methods.click(By.xpath("//h4[text()='Sepetim']"));
        methods.waitBySeconds(3);
        methods.click(By.xpath("//a[@id='js-cart']"));
        methods.waitBySeconds(3);
        methods.findElement(By.xpath("//input[@name='quantity']")).clear();
        methods.waitBySeconds(1);
        methods.sendKeys(By.xpath("//input[@name='quantity']"),"5");
        methods.waitBySeconds(1);
        methods.click(By.xpath("//i[@title='Güncelle']"));
        methods.waitBySeconds(5);
        methods.click(By.cssSelector("div[class='right']>a[class='button red']"));
        methods.waitBySeconds(2);
        methods.click(By.cssSelector("#shipping-tabs > a:nth-child(2)"));
        methods.waitBySeconds(1);
        methods.sendKeys(By.cssSelector("input[id='address-firstname-companyname']"), "Aleyna Zuhal");
        methods.sendKeys(By.cssSelector("input[id='address-lastname-title']"), "Isık");
        methods.selectByText(By.cssSelector("select[id='address-zone-id']"),"Antalya");
        methods.waitBySeconds(3);
        methods.selectByText(By.cssSelector("select[id='address-county-id']"),"MURATPAŞA");
        methods.waitBySeconds(3);
        methods.sendKeys(By.cssSelector("input[id='district']"), "Lara");
        methods.sendKeys(By.cssSelector("textarea[id='address-address-text']"), "Canım evim");
        methods.waitBySeconds(3);
        methods.sendKeys(By.cssSelector("input[id='address-postcode']"), "07040");
        methods.waitBySeconds(3);
        methods.sendKeys(By.cssSelector("input[id='address-telephone']"), "5534456936");
        methods.waitBySeconds(3);
        methods.sendKeys(By.cssSelector("input[id='address-mobile-telephone']"), "5534456936");
        methods.waitBySeconds(3);
        methods.sendKeys(By.cssSelector("input[id='address-tax-id']"), "15031543686");
        methods.waitBySeconds(3);
        methods.click(By.cssSelector("button[id='button-checkout-continue']"));
        methods.waitBySeconds(10);
        methods.click(By.cssSelector("button[id='button-checkout-continue']"));
        methods.waitBySeconds(3);
        methods.sendKeys(By.cssSelector("input[id='credit-card-owner']"), "Aleyna Zuhal Isık");
        methods.waitBySeconds(3);
        methods.sendKeys(By.cssSelector("input[id='credit_card_number_1']"), "1234123412341234");
        methods.waitBySeconds(3);
        methods.selectByText(By.cssSelector("select[id='credit-card-expire-date-month']"),"02");
        methods.waitBySeconds(3);
        methods.selectByText(By.cssSelector("select[id='credit-card-expire-date-year']"),"2022");
        methods.waitBySeconds(3);
        methods.sendKeys(By.cssSelector("input[id='credit-card-security-code']"), "6666");
        methods.waitBySeconds(3);
        methods.click(By.cssSelector("label[id='credit-card-is-3ds-label']"));
        methods.waitBySeconds(3);
        methods.click(By.cssSelector("label[id='register-credit-card-label']"));
        methods.waitBySeconds(3);
        methods.click(By.cssSelector("button[id='button-checkout-continue']"));
        methods.waitBySeconds(3);
        String text = methods.getText(By.cssSelector("span[class='error']"));
        methods.waitBySeconds(3);
        System.out.println("Alınan text:" + text);
        logger.info("Alınan text:"+ text);
        methods.waitBySeconds(3);
        methods.click(By.cssSelector("#logo > a > img"));
        methods.waitBySeconds(3);
        methods.scrollWithAction(By.cssSelector("#header-top > div > div.welcome.fl > div.menu.top.login > ul > li > a"));
        methods.click(By.cssSelector("#header-top > div > div.welcome.fl > div.menu.top.login > ul > li > div > ul > li:nth-child(4) > a"));

    }
    public void selectRandomProduct() {
        List<WebElement> productList = methods.findAllElements(By.cssSelector(".pr-img-link"));
        int randNum = random.nextInt(productList.size()-1);
        productList.get(randNum).click();
    }
}
