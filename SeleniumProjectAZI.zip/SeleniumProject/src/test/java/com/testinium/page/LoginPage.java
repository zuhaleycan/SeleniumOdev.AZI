package com.testinium.page;

import com.testinium.methods.Methods;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;

public class LoginPage {
    Methods methods;
    Logger logger = LogManager.getLogger(Methods.class);

    public LoginPage(){
        methods = new Methods();
    }

    public void login(){
        methods.click(By.cssSelector("div[class='menu-top-button login']>a"));
        methods.sendKeys(By.id("login-email"),"aleynazuhal.isik@testinium.com");
        methods.sendKeys(By.id("login-password"),"Aleyna0707");
        methods.click(By.cssSelector(".ky-btn.ky-btn-orange.w-100.ky-login-btn"));
        methods.waitBySeconds(20);
    }
    public  void textControlTest(){
        String text =methods.getText(By.cssSelector(".menu.top.login>ul>li>a>b"));
        System.out.println("Alınan text: " + text);
        logger.info("Alınan text:"+text);
        methods.waitBySeconds(2);

    }
}
